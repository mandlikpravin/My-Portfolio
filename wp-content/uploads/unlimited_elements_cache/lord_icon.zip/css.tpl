#{{uc_id}}{
  transition:0.3s;
  display:flex;
  position: relative;
}

#{{uc_id}} .ue-lord-icon-link{
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
}

#{{uc_id}} .ue-lord-icon-holder{
  display: inline-flex;
  justify-content: center;
  align-items: center;
}

#{{uc_id}} .ue-lord-icon-holder{
  {% if pulse_effect == "true" %}animation: pulse{{uc_id}} 1.5s infinite;{% endif %}
  {% if pulse_effect == "true" %}box-shadow: 0 0 0 0 {{pulse_color}};{% endif %}
}

#{{uc_id}} lord-icon{
  flex-shrink:0;
  flex-grow:0;
}

#{{uc_id}} .ue-box-button{
  width:100%;
}

#{{uc_id}} .ue-btn {
	text-decoration:none;
	transition: 0.3s;
    text-align:center;
}

{% if ucfunc("run_code_once", "yourkey") == true %}

	.ue-box-title    {
      font-size:21px;
    }

{% endif %}



@keyframes pulse{{uc_id}} {
	 0% {
		transform: scale(0.95);
		box-shadow: 0 0 0 0 {{pulse_color}};
	}
	
	70% {
		transform: scale(1);
		box-shadow: 0 0 0 20px {{pulse_color}};
	}
	
	100% {
		transform: scale(0.95);
		box-shadow: 0 0 0 0 {{pulse_color}};
	}
}