{{ ucfunc("put_docready_start") }}
		
var objWidget = jQuery("#{{uc_id}}");
var selectedCursor = objWidget.data("cursor");
var objParentTemplate = objWidget.parents(".uc-template-holder");
var isInTemplate = objParentTemplate && objParentTemplate.length > 0;
  
// Start cursor-1: Custom Cursor
{% if cursor_type == "cursor-1" %}
  var cursorOne = new ueCustomCursor1();
 
  if(isInTemplate == true){
    var objBody = jQuery("body");
    var parentTemplateId = objParentTemplate.attr("id");
    var objTemplateApplyTo = jQuery("#"+parentTemplateId);
    
    if("{{apply_cursor_trail_to}}" == "page")
    cursorOne.init("{{apply_cursor_trail_to}}", "#"+parentTemplateId, "{{uc_id}}");
    else
    cursorOne.init("{{apply_cursor_trail_to}}", "{{selection_cursor_trail_class_id|raw}}", "{{uc_id}}");
    
  }else{
    cursorOne.init("{{apply_cursor_trail_to}}", "{{selection_cursor_trail_class_id|raw}}", "{{uc_id}}");
  }
{% endif %}
// End cursor-1: Custom Cursor



// Start cursor-2: Custom Cursor
{% if cursor_type == "cursor-2" %}
  var ueObjCursor = objWidget.find(".ue-custom-cursor");
  var objCustomCursor = objWidget.find(".ue_cursor-item--2");
  var customCursorApplyTo = "{{apply_custom_cursor_to}}";
  var objApplyTo = jQuery('{{selection_custop_cursor_class_id|raw}}');
  var isMouseOver = false;
  var attentionGrabberClass = "{{attention_grabber}}";
 
  /**
  * on obj apply to mouseleave hide cursor
  */
  function onObjApplyMouseleave(){
    isMouseOver = false;
  	objCustomCursor.hide();    
  }
 
  /**
  * on obj apply to mouseenter hide cursor
  */
  function onObjApplyMouseenter(){
    isMouseOver = true;
  	objCustomCursor.show();
  }
 
  /**
  * on obj apply to mouseover
  */
  function onObjApplyMouseover(){
    isMouseOver = true;
  }
 
  //check if cursor widget is visible
  function isCursorWidgetVisible(){
    var objWidget = jQuery("#{{uc_id}}[data-cursor='cursor-2']");
    
    if(objWidget.is(":visible") == false)
      return(false);
    else
      return(true);
  }
 
  var isVisible = isCursorWidgetVisible();
 
  setTimeout(function(){
     if(isVisible == false)
      return(false);
  }, 500);
  
  {% if disable_on_touch_devices == "true" %}
    if (matchMedia('(pointer:fine)').matches) {
  {% endif %}
  
    var ue_outer_cursor = document.querySelector('#{{uc_id}} .cursor__ball--big');
    var ue_inner_cursor = document.querySelector('#{{uc_id}} .cursor__ball--small');
    var ue_hoverables = document.querySelectorAll('a,button,input,select,textarea');
    let cursorTimeout = 0;
   
    {% if hide_cursor_if_not_moving == "true" %}
    	setInterval(function(){
          cursorTimeout = cursorTimeout + 300;
          
          if(cursorTimeout >= Number({{hide_delay}}))
            ueCursorOutPage();
          else
            ueCursorInPage();
          
          
        }, 300);
    {% endif %}

    // Event Listeners for both mouse and touch events
    document.body.addEventListener('mousemove', ueOnMouseMove);
    document.body.addEventListener('touchmove', ueOnTouchMove);
    document.body.addEventListener('mouseleave', ueOnMouseLeave);
    document.body.addEventListener('mouseenter', ueOnMouseEnter);   
   
    {% if apply_custom_cursor_to == "id-class" %}
    	if(isMouseOver == true)
        objCustomCursor.show();
        else
        objCustomCursor.hide();
     
    	objApplyTo.on("mouseleave", onObjApplyMouseleave);
     	objApplyTo.on("mouseenter", onObjApplyMouseenter);
	    objApplyTo.on("mouseover", onObjApplyMouseover);
    {% endif %}

    // Move the cursor with mouse
    function ueOnMouseMove(e) {
      cursorTimeout = 0;
      moveCursor(e.clientX, e.clientY);
    }

    // Move the cursor with touch
    function ueOnTouchMove(e) {
      const touch = e.touches[0];
      if (touch) {
        moveCursor(touch.clientX, touch.clientY);
      }
    }

    // Move the cursor to a specific position
    function moveCursor(x, y) {
      {% if show_outer_cursor == "true" %}
        TweenMax.to(ue_outer_cursor, {% if outer_cursor_delay is not empty %}{{outer_cursor_delay}}{% else %}0{% endif %}, {
          x: x - {{cursor_size_outer_nounit/2}},
          y: y - {{cursor_size_outer_nounit/2}}
        })
      {% endif %}
      TweenMax.to(ue_inner_cursor, {% if outer_cursor_delay_inner is not empty %}{{outer_cursor_delay_inner}}{% else %}0{% endif %}, {
        x: x - {{cursor_size_inner_nounit/2}},
        y: y {{pointer_event_position}} {{cursor_size_inner_nounit/2}}
      })
    }

    // Hover an element
    {% if show_outer_cursor == "true" %}
      for (let i = 0; i < ue_hoverables.length; i++) {
        ue_hoverables[i].addEventListener('mouseenter', ueOnMouseHover);
        ue_hoverables[i].addEventListener('mouseleave', ueOnMouseHoverOut);
        ue_hoverables[i].addEventListener('touchstart', ueOnTouchStart);
      }

      function ueOnMouseHover() {
        TweenMax.to(ue_outer_cursor, .3, {
          scale: {{outer_cursor_hover_scale}},
          opacity:{{outer_cursor_hover_opacity}}
        })
      }
      function ueOnMouseHoverOut() {
        TweenMax.to(ue_outer_cursor, .3, {
          scale: 1,
          opacity:1
        })
      }
      // Touch start event for hoverables
      function ueOnTouchStart() {
        // Prevent default behavior to avoid double click on touch devices
        event.preventDefault();
        // Trigger hover effect
        ueOnMouseHover();
      }
    {% endif %}

    // Add class "cursor-inactive" when mouse leaves the page and remove when mouse is in page
    function ueOnMouseLeave(e) {
      if (e.clientY <= 0 || e.clientX <= 0 || (e.clientX >= window.innerWidth || e.clientY >= window.innerHeight)) {
        ueCursorOutPage();
      }
    }
    function ueOnMouseEnter() {
      ueCursorInPage();
    }
    // Hide the cursor
    function ueCursorOutPage() {
      objCustomCursor.addClass("cursor-inactive");
    }
    // Show the cursor
    function ueCursorInPage() {
      objCustomCursor.removeClass("cursor-inactive");
    }
   
{% if disable_on_touch_devices == "true" %} 
  }else{
    objCustomCursor.hide();
  };
     
{% endif %}
{% endif %}
// End cursor-2: Custom Cursor


// Start cursor-3: Custom Cursor
{% if cursor_type == "cursor-3" %}

  var objApplyTo = jQuery(' {% if apply_effect_to == "page" %} body{% endif %} {% if apply_effect_to == "id-class" %} {{section_class_id|raw}} {% endif %} ');
 
  var options = {
    widgetId: '{{uc_id}}',
    image_path: '{{uc_assets_url}}jstars',
	image: '{{shine_style}}',
	style: '{{shine_color}}', // yellow, green, red, white, blue
	frequency: {{frequency}},
	delay: {{delay}},
    ue_scale: {{shine_scale}},
    ue_end_scale: {{shine_end_scale}},
   {% if shine_style in ['style_1.webp', 'style_2.webp'] %}
	width: 50, // single star width
	height: 50, // single star height
    style_map: { 
		blue: 0,
		cyan: -50,
		black: -100,
		green: -150,
		orange: -200,
        grey: -250,
        red: -300,
        pink: -350,
        golden: -400,
        violet: -450,
        white: -500
	},
   {% endif %}
   {% if shine_style in ['style_3.webp', 'style_4.webp'] %}
	width: 25, // single star width
	height: 25, // single star height
    style_map: { 
		blue: 0,
		cyan: -25,
		black: -50,
		green: -75,
		orange: -100,
        grey: -125,
        red: -150,
        pink: -175,
        golden: -200,
        violet: -225,
        white: -250
	},
   {% endif %} 
  }
    
  function destroyJSStars(){
    objApplyTo.jstars('destroy');
  }  
    
  function initJSStars(){
    objApplyTo.jstars(options);
  }  
    
  if(isInTemplate == true){
    var objBody = jQuery("body");
    var parentTemplateId = objParentTemplate.attr("id");
    var objTemplateApplyTo = jQuery("#"+parentTemplateId);
    
    if("{{apply_effect_to}}" == "page")
    objTemplateApplyTo.jstars(options); 
    else
    objApplyTo.jstars(options); 
   
  }else{
    objApplyTo.jstars(options);
  }
{% endif %}
// End cursor-3: Custom Cursor
    	
{{ ucfunc("put_docready_end") }}