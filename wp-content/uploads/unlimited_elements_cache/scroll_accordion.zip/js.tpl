{{ ucfunc("put_docready_start") }}

  var objScrollAccordion = jQuery("#{{uc_id}}");
  var objScrollAccordionWrapper = objScrollAccordion.find('.ue_cards_wrapper');
  var objCards = objScrollAccordion.find('.ue_scroll_accordion_item');
  var classActive = "ue-active";
  var classActiveLocal = "ue-active-local";
  var cardsStartPositions = getCardsStartPositions();
  var isClicked = false;

  //enable stiky position to calculate start position of all items
  enableStickyPos();

  {% if disable_section_id_source_js != "true" %}
	
	var objScrollAccordionSection = new ueScrollAccordion();
  
    objScrollAccordionSection.init("#{{uc_id}}");
   
  {% endif %}

  {% if scroll_related_animation == "true" %}
    
    var numCards = objCards.length; 

    gsap.registerPlugin(ScrollTrigger);

    objCards.each(function(index0) {
        const card = jQuery(this);
        const index = index0 + 1;
        const reverseIndex0 = numCards - index;

        // Scroll Related Styles
        gsap.to(card[0], {
            duration: 2,
            {% if scale_end_nounit is not empty %}scale: 1 + ({{ scale_end_nounit / 10 }}),{% endif %}
            rotate: {{rotation_end}},
            {% if opacity_end_nounit is not empty %} opacity: {{opacity_end_nounit / 100}},{% endif %}
            {% if (blur_end_nounit is not empty) or (greyscale_end_nounit is not empty) %}
              filter:  {% if blur_end_nounit is not empty %}`blur(${{{blur_end_nounit}}}px){% endif %} {% if greyscale_end_nounit is not empty %}grayscale(${{{greyscale_end_nounit}}}%){% endif %}`,
           {% endif %}
          
            scrollTrigger: {
                trigger: objScrollAccordionWrapper[0],
                start: `${(index0 / numCards) * 100}% 0%`,  // Start at each card’s section
                end: "center -120%", // End at next wrapper section
                scrub: true,
                onToggle: (self) => {
                  
                  objScrollAccordion.trigger("ue_scroll_accordion_change")
                },
                onEnter: function(){                  
                 // on Enter functions
                 
                },
                onLeaveBack: function(){
                 // or leave functions
                 // objScrollAccordion.trigger("ue_scroll_accordion_change")
                }
            },
        });
    });
                                                                                            
  {% endif %}//end scroll_related_animation  
    
  /**
  * enable sticky position
  */
  function enableStickyPos(){
    if(!objCards || objCards.length == 0)
    return(false);
      
    objCards.css("position", "sticky");
  }   
                                                                                            
  /**
  * gety cards init positions
  */
  function getCardsStartPositions(){
    var cardsStartPositionsArray = [];
     
    if(!objCards || objCards.length == 0)
    return(null);
      
    objCards.each(function(){
      var objCard = jQuery(this);
      var cardOffset = objCard.offset().top;
        
      cardsStartPositionsArray.push(cardOffset);
    });
      
    return(cardsStartPositionsArray);
  }                                                                                        
       
  /**
  * get active index
  */
  function getActiveIndex(){
    var index;
    var objActiveCard = objScrollAccordion.find("."+classActive);
      
    if(!objActiveCard || objActiveCard.legnth == 0)
      return(null);
      
    index = objActiveCard.index();
    return(index);
  }
  
  /**
  * scroll
  */
  function scrollTo(changePosition, time){
    jQuery('html, body').animate({
        scrollTop: changePosition
    }, time)
  }       
   
  var ScrollAccordioneElem = document.querySelector("#{{uc_id}}");
  var objCards = Array.from(ScrollAccordioneElem.querySelectorAll(".ue_scroll_accordion_item"));

  function updateActiveCard() {
        let activeCard = null;
        let minDistance = window.innerHeight; // Start with max possible distance

        objCards.forEach(card => {
            let rect = card.getBoundingClientRect();

            // Check if card is fully visible
            if (rect.top >= 0 && rect.bottom <= window.innerHeight) {
                let distanceToTop = Math.abs(rect.top); // Distance from top of viewport

                // Select the closest fully visible card to the top
                if (distanceToTop < minDistance) {
                    minDistance = distanceToTop;
                    activeCard = card;
                }
            }
        });

        // Remove active class from all cards
        objCards.forEach(card => card.classList.remove(classActiveLocal));

        // Add active class to the detected active card
        if (activeCard) {
            activeCard.classList.add(classActiveLocal);
        }
  }

  // Listen to scroll and call update function
  window.addEventListener("scroll", updateActiveCard);
  window.addEventListener("resize", updateActiveCard); // Handle resizes

  // Run once on load in case a card is already in position
  updateActiveCard(); 
    
  //vars
                                                                                                                           
  //events                                                                                        
  objScrollAccordion.on("uc_change", function(e){
    var activeIndex = getActiveIndex();
	
    if(activeIndex == null)
      return(true);
    
    if(isClicked == true)
      return(true);
    
    isClicked = true;
    
    setTimeout(function(){
    	isClicked = false;
    },200);    
     
    var activeOffset = cardsStartPositions[activeIndex];
      
    //scroll to selected item
    scrollTo(activeOffset, 100);
    
    
  });                                                                                    
    
  var objRemoteOptions = {
    	class_items:"ue_scroll_accordion_item",
    	class_active:"ue-active",
    	selector_item_trigger:null,
        add_set_active_code:true
  };
      
  {{ucfunc("put_remote_parent_js","objScrollAccordion","objRemoteOptions")}} 
 
{{ ucfunc("put_docready_end") }}