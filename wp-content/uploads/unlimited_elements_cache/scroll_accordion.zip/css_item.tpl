#{{uc_id}} .{{item.item_repeater_class}} {
  padding-top: calc({{item.item_index - 1}} * var(--card-top-offset))!important;
}