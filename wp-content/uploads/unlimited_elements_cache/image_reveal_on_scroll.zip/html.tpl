<div class="uc_image_reveal" id="{{uc_id}}">
	<div class="uc_image_reveal_box">
      	{% if (show_link == "true") %}
      	<a href="{{image_link}}" {{image_link_html_attributes|raw}}>
      	{% endif %}
          
		<img src="{{image}}" class="ue-img" alt="" width="100%" {{image_attributes|raw}}>
          
        {% if (show_link == "true") %}
      	</a>
      	{% endif %}
      
		<div class="uc_overlay iv-jello"></div>
        
	</div>
</div>