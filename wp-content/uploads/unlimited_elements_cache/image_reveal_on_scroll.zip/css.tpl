{% if direction == "left" or direction == "right" %}
    #{{uc_id}} .uc_overlay{
      {{direction}}: 0;
	} 
{% endif %}	

{% if direction == "top" or direction == "bottom" %}
    #{{uc_id}} .uc_overlay.uc_reveal{
      height: 0;
      width: 100%;
      {{direction}}: 0;
	} 
{% endif %}

{% if direction == "bottom" %}
	#{{uc_id}} .uc_overlay.uc_reveal{
      top: unset;
	}
{% endif %}


#{{uc_id}} .uc_reveal{
	transition: ease-in-out all {{animation_speed}}s;
    transition-delay: {{transition_delay}}ms;
}

#{{uc_id}} img
{
  display:block;
}