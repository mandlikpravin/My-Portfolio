jQuery(document).ready(function(){
  
  	var objImageReveal = jQuery('#{{uc_id}}');
  	var objOverlay = objImageReveal.find('.uc_overlay');
  	var revealClass = 'uc_reveal';
  
    jQuery(objImageReveal).on('inview', function(event, isInView) {
      	
        if (isInView == true)
        objOverlay.addClass(revealClass);
      	
        {% if reveal_each_time_on_scroll == "true" %}
        
          if(isInView == false)
          objOverlay.removeClass(revealClass);
          
        {% endif %}	
      	
    });
});