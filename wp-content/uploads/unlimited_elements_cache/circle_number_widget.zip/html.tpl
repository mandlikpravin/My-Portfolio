<div id="{{uc_id}}" class="circle_number_widget_container">
  
    {% if linkable == "true" %}<a style="display:block;" href="{{link}}" {{link_html_attributes|raw}}>{% endif %}
    <div class="circle_number_widget_layout">
      
    <div class="ue-number-container {{hover_animation}}"> 
    <div class="circle_number_widget">
      <div class="circle_number_text">{{text|raw}}</div>
    </div>
    </div>
    
    {% if layout == "row" %}
      <div class="ue-spacing"></div>
    {% endif %}
    
    <div class="ue-widget-content">
    {% if show_title == "true" %}<div class="ue-title">{{title|raw}}</div>{% endif %}
    {% if show_description == "true" %}<div class="ue-description">{{description|raw}}</div>{% endif %}
    </div>
  
  
    </div>
    {% if linkable == "true" %}</a>{% endif %}
</div>