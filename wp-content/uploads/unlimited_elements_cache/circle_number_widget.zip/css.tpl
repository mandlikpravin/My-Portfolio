#{{uc_id}} .circle_number_widget_layout
{
  display:flex;
  {% if layout == "row" %}
     align-items:center;
  {% endif %}
}
#{{uc_id}} .circle_number_widget
{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  position:relative;
  transform:rotate({{rotate}}deg);
  {% if pulse_effect == "true" %}animation: pulse{{uc_id}} 1.5s infinite;{% endif %}
  {% if pulse_effect == "true" %}box-shadow: 0 0 0 0 {{pulse_color}};{% endif %}
}

#{{uc_id}} .circle_number_text
{
  transform:rotate(-{{rotate}}deg);
}





#{{uc_id}} .ue-number-container, #{{uc_id}} .ue-spacing
{
  flex-grow:0;
  flex-shrink:0;
}

.circle_number_widget
{
  font-size:32px;
}
.ue-title
{
  font-size:21px;
}


@keyframes pulse{{uc_id}} {
	 0% {
		transform: scale(0.95);
		box-shadow: 0 0 0 0 {{pulse_color}};
	}
	
	70% {
		transform: scale(1);
		box-shadow: 0 0 0 20px {{pulse_color}};
	}
	
	100% {
		transform: scale(0.95);
		box-shadow: 0 0 0 0 {{pulse_color}};
	}
}