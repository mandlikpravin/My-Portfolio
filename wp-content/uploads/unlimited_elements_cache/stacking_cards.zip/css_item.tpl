.{{item.item_repeater_class}} {
  padding-top: calc({{item.item_index}} * var(--card-top-offset))!important;
}