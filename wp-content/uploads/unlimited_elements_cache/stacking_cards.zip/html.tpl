<div id="{{uc_id}}" data-editor="{{uc_inside_editor}}" data-errors="{{show_errors}}" data-show-section="{{hide_sections_in_editor}}" class="ue_stacking_cards_widget uc_creative_buttons {{uc_filtering_addclass}} {{remote_parent.class}}" {{uc_filtering_attributes|raw}} {{remote_parent.attributes|raw}} dir="{{rtl}}">
  <div class="ue_cards_wrapper uc-items-wrapper">
    {{put_items()}}
  </div>
</div>