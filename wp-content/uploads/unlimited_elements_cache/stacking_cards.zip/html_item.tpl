<div class="ue_stacking_card_item {{item.item_repeater_class}} ueitem-{{item.item_index}}" data-source="{{item.content_type}}" data-id="{{item.section_id|raw}}">
  <div class="ue_card_content" {% if show_background_image == "true" %}style="background-image: url({{item.background_image}});"{% endif %}>
    
    {% if item.content_type == "normal" %}
      <div class="ue_content_left">
        {% if show_graphic_element != "no" %}
          <div class="ue_sc_graphic_el">
            {% if show_graphic_element == "icon" %}{{item.graphic_icon_html|raw}}{% endif %}
            {% if show_graphic_element == "img" %}<img src="{{item.graphic_image}}" {{item.graphic_image_attributes|raw}}>{% endif %}
            {% if show_graphic_element == "text" %}{{item.graphic_text|raw}}{% endif %}
          </div>
        {% endif %}
        {% if show_title == "true" %}<{{title_html_tag}} class="ue_sc_title">{{item.title|raw}}</{{title_html_tag}}>{% endif %}
        {% if show_description == "true" %}<div class="ue_sc_desc">{{item.description|raw}}</div>{% endif %}
	    {% if show_button == "true" and item.show_button == "true" %}<a href="{{item.link}}" {{item.link_html_attributes|raw}} class="ue_sc_button uc_button {{styles}}"><span>{% if item.button_text is empty %}{{button_text|raw}}{% else %}{{item.button_text|raw}}{% endif %}</span></a>{% endif %}
      </div>
	  {% if show_image == "true" %}
        <figure>
          {% if enable_lightbox == "true" %}<a class="ue-link" href="{{item.image}}">{% endif %}
            <img class="ue_sc_img" src="{% if item.image is not empty %}{{item.image}}{% else %}{{uc_assets_url}}/default/placeholder.png{% endif %}" alt="Image description" {{item.image_attributes|raw}} alt="{{item.image_alt}}" title="{{item.image_title}}">
          {% if enable_lightbox == "true" %}</a>{% endif %}
  		</figure>
      {% endif %}
    {% endif %}
  
    {% if item.content_type == "template" %}
      <div class="ue_content_wrapper ue_elem_template"> {{putElementorTemplate(item.template_templateid)}} </div>
    {% endif %}
  
    {% if item.content_type == "section_id" %}
      <div class="ue_content_wrapper ue_section_id"></div>
    {% endif %}
  
  </div>
</div>