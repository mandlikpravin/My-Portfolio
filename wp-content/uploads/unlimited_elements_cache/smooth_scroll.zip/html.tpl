{%  if(uc_inside_editor == "yes") %}
  <div style="color:red;text-align:center;">This is <strong>Smooth Scroll Page widget</strong> (only works in frontend)</div>
{% endif %}