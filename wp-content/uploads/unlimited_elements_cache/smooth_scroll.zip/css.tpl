{% if hide_scrollbar == "true" %}
  ::-webkit-scrollbar {
    display: none; /* for Chrome, Safari, and Opera */
  }
  body{
     scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none;  /* Internet Explorer 10+ */
  }
{% endif %}

html{
  scroll-behavior: auto;
}