{%  if(uc_inside_editor != "yes") %}

jQuery(document).ready(function () {
    const lenis = new Lenis({
      duration: {{scroll_duration}},	
      {% if (linear_interpolation == "true") and (linear_interpolation_value is not empty) %} // lerp: 0.5, {% endif %}	
      smoothWheel: {{smoothwheel}},
      smoothTouch: {{smoothtouch}},

      syncTouch: {{sync_touch}},
      {% if sync_touch == "true"%} syncTouchLerp: {{sync_touch_lerp}},{% endif %}
      {% if sync_touch == "true"%} touchInertiaMultiplier: {{touch_inertia_multiplier}}, {% endif %}

      wheelMultiplier:{{mouse_wheel_multiplier}},
      touchMultiplier: {{touch_multiplier}},
      infinite: {{infinite_scroll}},
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t))
    });

    function raf(time) {
        lenis.raf(time);
        ScrollTrigger.update();
        requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);
 
   document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const id = link.getAttribute('href');
      const target = document.querySelector(id);
      if (target) {
        lenis.scrollTo(target);
      }
    });
  });
});

{% endif %}