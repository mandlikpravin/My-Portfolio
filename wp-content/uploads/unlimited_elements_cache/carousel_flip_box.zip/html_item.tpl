{# twig vars #}{##}
{% set frontIconElem %}<div class="ue-flip-box__panel__element ue-flip-box__icon">{{item.front_icon_html|raw}}</div>{% endset %}
{% set backIconElem %}<div class="ue-flip-box__panel__element ue-flip-box__icon">{{item.back_icon_html|raw}}</div>{% endset %}
{% set flipboxIconsElem %}
  <div class="ue-flip-box-icons">
    {% if item.icon_one is empty %}{% else %}<a class="{{icon_hover_effect}}" href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
    {% if item.icon_two is empty %}{% else %}<a class="{{icon_hover_effect}}" href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
    {% if item.icon_three is empty %}{% else %}<a class="{{icon_hover_effect}}" href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
    {% if item.icon_four is empty %}{% else %}<a class="{{icon_hover_effect}}" href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
  </div>
{% endset %}
{# end twig vars #}{##}

<div class="ue-flip-box ue-flip-box-{{item.item_index}} {{item.item_repeater_class}} {% if carousel_type == "marquee" %}uc_logo_marquee_holder{% endif %}" id="{{item.item_id}}">
  
  {% if ( anim_effect == "fade" ) or ( anim_effect == "zoomin" ) or ( anim_effect == "zoomout" ) or ( anim_effect == "zoominout" )%}
  	<div class="ue-flip-box__container uc-hide {{anim_effect}} ue-flip-box__container--{{animation_trigger}}">
  {% else %}
    <div class="ue-flip-box__container uc-hide {{anim_effect}}_{{anim_direction}} ue-flip-box__container--{{animation_trigger}}">
  {% endif %}
    
    <div class="ue-flip-box__panel ue-flip-box__panel--front {{item.item_repeater_class}}">
      <div class="ue-flip-box__panel--front-overlay"></div>
      {% if animation_trigger == "trigger_button" %}<a href="javascript:void(0)" class="ue-flip-box__front-trigger">{{item.front_trigger_html|raw}}</a>{% endif %}
      <div class="ue-flip-box__panel__wrapper">
        <div class="ue-flip-box__panel__content">
          	{% if show_front_image == "true" %}<div class="ue-flip-box__panel__element ue-flip-box__image"><img src="{{item.front_image}}" {{item.front_image_attributes|raw}} /></div>{% endif %}
            {% if show_front_icon == "before" %}{{frontIconElem}}{% endif %}
            {% if show_front_title == "true" %}<div class="ue-flip-box__panel__element ue-flip-box__title">{{item.title|raw}}</div>{% endif %}
            {% if show_front_icon == "after" %}{{frontIconElem}}{% endif %}
            {% if show_front_text == "true" %}<div class="ue-flip-box__panel__element ue-flip-box__description">{{item.front_text|raw}}</div>{% endif %}
          
        </div>
      </div>
    </div>	
    
    <div  class="ue-flip-box__panel ue-flip-box__panel--back">
      <div class="ue-flip-box__panel--back-overlay"></div>
      {% if animation_trigger == "trigger_button" and show_back_trigger_button == "true" %}<a href="javascript:void(0)" class="ue-flip-box__back-trigger">{{item.back_trigger_html|raw}}</a>{% endif %}
      <div class="ue-flip-box__panel__wrapper">
        <div class="ue-flip-box__panel__content">

          {% if show_back_icon == "before" %}{{backIconElem}}{% endif %}
          {% if show_back_title == "true" %}<div class="ue-flip-box__panel__element ue-flip-box__title">{{item.back_title|raw}}</div>{% endif %}
          {% if show_back_icon == "after" %}{{backIconElem}}{% endif %}
          {% if show_back_text == "true" %}<div class="ue-flip-box__panel__element ue-flip-box__description">{{item.back_text|raw}}</div>{% endif %}
          {% if show_back_button == "true" %}
          	<div class="ue-flip-box__panel__element ue-flip-box__button">
              <a href="{{item.button_link}}" class="ue_btn" {{item.button_link_html_attributes|raw}}>
              {% if item.button_text|raw is empty %} 
                {{button_text|raw}}
              {% else %}   
              	{{item.button_text|raw}}
              {% endif %}  
              </a>
          	</div>
          {% endif %}
          
          {% if show_icons == "true" and change_back_link_icons_position_to_outside == "false" %}{{flipboxIconsElem}}{% endif %}
          
        </div>
      </div>
    </div>
    
  </div>
  
  {% if show_overlay == "true" %}
  	<div class="ue-flip-box__overlay"></div>
  {% endif %}
      
  {% if show_icons == "true" and change_back_link_icons_position_to_outside == "true" %}{{flipboxIconsElem}}{% endif %}
      
</div>