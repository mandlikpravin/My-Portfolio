{% if item.override_image_background == "true" %}
#{{uc_id}} .ue-flip-box-{{item.item_index}} .ue-flip-box__panel--front    {
      background-image:url({{item.front_image_background_override}});
      background-repeat:no-repeat;
    } 
{% endif %}

{% if item.override_back_bg_image == "true" %}
#{{uc_id}} .ue-flip-box-{{item.item_index}} .ue-flip-box__panel--back    {
      background-image:url({{item.back_image_background_override}});
      background-repeat:no-repeat;
    } 
{% endif %}