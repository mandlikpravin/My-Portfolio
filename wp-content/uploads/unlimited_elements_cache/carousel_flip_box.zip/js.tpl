{{ ucfunc("put_docready_start") }}
		
  var objWidget = jQuery('#{{uc_id}}');
 
  /**
  * init flipbox
  */
  function initFlipbox(){        
    var objFlips = objWidget.find(".ue-flip-box"); 
    
    jQuery.each(objFlips,function(index, flip){      	
      	var objFlip = jQuery(flip);
      
        new UEFlipboxItem(objFlip);           
    });    
  }
  
  //carousel type owl
  {% if carousel_type == "owl" %}	
    /**
    * init owl
    */
    function initCarousel(){      
          objWidget.owlCarousel({
              loop: {{loop}},
              rtl: {{rtl}},
              setActiveClassOnMobile:{{active_on_mobile}},
              changeItemOnClick:{{scroll_on_click}},
              center:{{center}},                              
              margin:{{margin_between_slides}},                          
              autoplay:{{autoplay}},
              autoplayHoverPause:{{autoplayhoverpause}},
              paddingType: "{{stage_padding_type}}",                     
              slideTransition: '{{slide_transition}}',
              autoplayTimeout:{{autoplay_interval}},
              smartSpeed: {{transition_speed}},
              {% if dots_navigation == "false" %}
              dots: false,
              {% endif %}	                            
              {% if dots_navigation == "true" %}
              dots: true,
              {% endif %}	
              {% if arrow_navigation == "false" %}                               
                  nav: false,
              {% endif %}	
              {% if arrow_navigation == "true" %}                               
                  nav: true,
                  navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],
              {% endif %}	
              responsiveClass: true,
              mouseDrag:{{disable_mouse_drag}},
              touchDrag:{{disable_touch_drag}},
              responsive: {
                      0 : {
                          items:{{number_of_items_mobile}},

                          {% if stage_padding_type != "none" %}
                               stagePadding: {{stage_padding_mobile}}
                          {% endif %}	        
                      },
                      768 : {
                          items:{{number_of_items_tablet}},

                          {% if stage_padding_type != "none" %}
                               stagePadding: {{stage_padding_tablet}}
                          {% endif %}	         
                      },
                      980 : {
                          items:{{number_of_items}},

                          {% if stage_padding_type != "none" %}
                               stagePadding: {{stage_padding}}
                          {% endif %}         
                      } 
              }
            });

          {{ucfunc("put_remote_parent_js","objWidget")}}  
    }

    //init carousel
    initCarousel();

    //init events
    objWidget.on("uc_ajax_refreshed",function(){      
          objWidget.trigger('destroy.owl.carousel');      
          initCarousel();  
    });
   
  {% endif %}
  //end carousel type owl 
  
  //carousel type marquee
  {% if carousel_type == "marquee" %}
  
    var objMarquee = objWidget.find('.uc_marquee');

    UCMarquee(objMarquee);

    objWidget.on("uc_ajax_refreshed",function(){
          UCMarquee(objMarquee);     
     });
   
  {% endif %}
  //end carousel type marquee
  
  setTimeout(initFlipbox,500);
    	
{{ ucfunc("put_docready_end") }}