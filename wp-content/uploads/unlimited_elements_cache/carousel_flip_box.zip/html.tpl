<div class="ue-flipbox-carousel" >
  
  {# carousel type owl #}{##}
  {% if carousel_type == "owl" %}
    <div class="ue-carousel owl-carousel uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
       {{put_items()}}
    </div>
  {% endif %}
  {# end carousel type owl #}{##}
  
  {# carousel type marquee #}{##}
  {% if carousel_type == "marquee" %}
    <div class="uc_logo_marquee {{uc_filtering_addclass}} uc_marquee_{{direction_marquee}}" id="{{uc_id}}" style="direction:ltr;" {{uc_filtering_attributes|raw}}>
       <div class="uc_marquee ue-carousel uc-items-wrapper" data-height="{{box_height}}" data-speed="{{transition_speed_marquee}}" data-mobile-items="{{number_of_items_marquee_mobile}}" data-tablet-items="{{number_of_items_marquee_tablet}}" data-desktop-items="{{number_of_items_marquee}}" data-margin="{{margin_between_items_marquee}}" data-paused="{{autoplay_hover_pause_marquee}}" data-direction="{{direction_marquee}}">
            {{put_items()}}
       </div>	
    </div>
  {% endif %}
  {# end carousel type marquee #}{##}  
  
</div>