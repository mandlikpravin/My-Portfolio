{{ ucfunc("put_docready_start") }}
		
  var objBullets = jQuery('#{{uc_id}}');
  
  if(objBullets.hasClass("uc-remote-parent") == false)
      	return(false);
    
	var objRemoteOptions = {
    	class_items:"ue_item",
    	class_active:"ue_active",
    	selector_item_trigger:null,
      	add_set_active_code:true
    };
    
  	{{ucfunc("put_remote_parent_js","objBullets","objRemoteOptions")}}
    	
{{ ucfunc("put_docready_end") }}