#{{item.item_id}}{
  object-position:{{item.image_position}};
}

{% if split_mode == "true" %}
  #{{item.item_id}} {
    background-image:url({{item.image}});
    background-size:cover;
    background-repeat:none;
  }
	
  {% if hide_all_desk == "true" %}
    @media screen and (min-width: 768px){
      #{{uc_id}}:hover #{{item.item_id}} {
        background-image:none;
      }
    }    
  {% endif %}
{% endif %}

@media screen and (max-width: 767px) {
  {% if split_mode_mobile == "true" %}
    #{{item.item_id}} {
      background-image:url({{item.image}});
      background-size:cover;
      background-repeat:none;
    }
	
    {% if hide_all_mob == "true" %}
      #{{uc_id}}:hover #{{item.item_id}} {
        background-image:none;
      }
  	  #{{uc_id}} .uc_background_img img{
       	display: none;
      }
    {% endif %}
  {% endif %}
}