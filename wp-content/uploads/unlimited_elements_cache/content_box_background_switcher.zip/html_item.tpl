<div class="uc_hover_switcher_col uc_hover_switcher_col-{{item.item_index}}" id="{{item.item_id}}">
  <div class="ue-item-overlay"></div>
  <div class="uc_hover_switcher_content">
    {% if show_image_in_content == "true" and item.image_in_content is not empty %}
      {% if link_in_content_image == "true" %}<a href="{{item.button_link}}" {{item.button_link_html_attributes|raw}}>{% endif %}
        <div class="uc_hover_switcher_content-image"><img src="{{item.image_in_content}}" {{item.image_in_content_attributes|raw}} /></div>
      {% if link_in_content_image == "true" %}</a>{% endif %}
    {% endif %}
    {% if show_title == "true" %}
      {% if link_on_title == "true" %}<a href="{{item.button_link}}" {{item.button_link_html_attributes|raw}}>{% endif %}
        <{{title_html_tag}} class="uc_hover_switcher_title title_space">{{item.title|raw}}</{{title_html_tag}}>
      {% if link_on_title == "true" %}</a>{% endif %}
    {% endif %}
    <div class="uc_hover_switcher_link">
      {% if show_description == "true" %}<div class="uc_hover_switcher_desc">{{item.description|raw}}</div>{% endif %}
      {% if show_button == "true" %}
      	<a class="uc_button uc_more_btn" href="{{item.button_link}}" {{item.button_link_html_attributes|raw}}>
          {% if item.button_text|raw is empty %}
          	{{button_text|raw}}
          {% else %}
          	{{item.button_text|raw}}
          {% endif %}
      	</a>
      {% endif %}
    </div>
  </div>
</div>

<figure class="uc_background_img">
  <div class="uc_hover_switcher_overlay"></div>
  <img src="{{item.image}}" alt="{{item.image_alt}}" id="{{item.item_id}}">
</figure>