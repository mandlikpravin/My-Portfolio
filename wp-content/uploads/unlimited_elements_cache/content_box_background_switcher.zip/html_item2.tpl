<div class="uc_hover_remote_item">
  <div class="uc_hover_remote_segment"></div>
</div>