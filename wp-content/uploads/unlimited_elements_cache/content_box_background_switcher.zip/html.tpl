<div class="uc_list_image_background_hover_switcher {{remote_parent.class|raw}} {{uc_filtering_addclass}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}} data-first-selected="{{first_selected}}">
	<div class="uc_hover_switcher_row uc-items-wrapper">
		{{put_items()}}
	</div>
	<div class="uc_hover_remote_container uc-items-wrapper2">
  		{{put_items2()}}
  	</div>
</div>