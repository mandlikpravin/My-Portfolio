<div class="uc_material_bullets {{remote_parent.class}} {{uc_filtering_addclass}}"  id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>   	
    	<div class="ue-bullets uc-items-wrapper">
          	{{put_items()}}
      </div>
</div>