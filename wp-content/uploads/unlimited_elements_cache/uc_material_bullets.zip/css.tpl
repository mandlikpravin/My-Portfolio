#{{uc_id}} *{
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

#{{uc_id}} .ue-icon-wrapper{
	display: flex;
}

#{{uc_id}} .ue-icon{
  display:flex;
  align-items:center;
  justify-content:center;
  flex-grow:0;
  flex-shrink:0;
  line-height:1em;
  transition:0.3s;
}

#{{uc_id}} .ue-icon svg{
  height:1em;
  width:1em;
}

#{{uc_id}} .uc_material_bullets_row{
	font-weight:400;
	overflow:hidden;
	display:flex;
	position:relative;
	text-align:left;
	width:100%;   
    transition:0.3s;
}

#{{uc_id}} .uc_material_bullets_row a.ue-item-link{
  position:absolute;
  display:block;
  top:0;
  right:0;
  left:0;
  bottom:0;
}

#{{uc_id}} .uc_material_bullets_row:last-child{
	margin-bottom:0px !important;
}


#{{uc_id}} .uc_material_bullets_row {
	position:relative;
	vertical-align:middle;
}

#{{uc_id}} .uc_material_bullets_row .uc_content_box{
	display:flex;
    flex-direction:column;
    justify-content:center;
    align-items: flex-start;
    flex-grow:1;
}

#{{uc_id}} .ue-bullets{
  display:grid;
}

#{{uc_id}} .ue-text, 
#{{uc_id}} .ue-title, 
#{{uc_id}} .ue-seperator{
  width:100%;
}

#{{uc_id}} .ue-seperator-line{
  display:inline-block;
  font-size:0px;
}

#{{uc_id}} .ue-seperator{
  font-size:0px;
}

#{{uc_id}}.uc-remote-parent .uc_material_bullets_row{
  cursor:pointer;
}

.ue-title{
  font-size:21px;
  margin:0;
}

#{{uc_id}} .uc_content_box > *{
  transition: all .3s;
}