<div class="uc_material_bullets_row {{item.item_repeater_class}}">
  <div class="ue-icon-wrapper">
              <div class="ue-icon">
                   {% if item.graphic_element == "icon" %} {{item.icon_html|raw}} {% endif %}
                   {% if item.graphic_element == "text" %} <span class="ue-icon-text">{{item.icon_text|raw}}</span> {% endif %}	

                
              </div>
  </div>
  <div class="uc_content_box uc_ceal">
    <{{title_html_tag}} class="ue-title">{{item.title|raw}}</{{title_html_tag}}>
    
    {% if show_separator == "true" %}
      <div class="ue-seperator">
          <div class="ue-seperator-line"> </div>
      </div>
    {% endif %}	
    
    <div class="ue-text">{{item.content|raw}}</div>	
  </div>
  {% if item.link is empty %}
  {% else %} 
      <a href="{{item.link|raw}}" class="ue-item-link" {{item.link_html_attributes|raw}}></a>
  {% endif %}	
</div>